﻿

namespace APICountriesIA
{
    class MainAPI
    
    {
        static async Task Main(string[] args)
        {
            await App.Run();
        }
    }
}

