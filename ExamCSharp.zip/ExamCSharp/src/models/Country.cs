namespace APICountriesIA
{
    public class Country
    {
        public string Name { get; set; } = "unknown";
        public string Region { get; set; } = "unknown";
        public long Population { get; set; }
        public string Capital { get; set; } = "unknown";
    }
}
