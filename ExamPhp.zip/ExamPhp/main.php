<?php
    require_once __DIR__ . "/GlobalUsing.php";
    $app = new App();
    $app->runApp();
?>